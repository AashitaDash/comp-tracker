import React from 'react';
import { 
  TrendingUp, 
  Eye, 
  AlertCircle, 
  Clock,
  ArrowUp,
  ArrowDown,
  DollarSign,
  Star,
  Zap,
  Bell,
  Download
} from 'lucide-react';
import UpdateCard from '../components/UpdateCard';
import CompetitorCard from '../components/CompetitorCard';
import SearchAndFilter from '../components/SearchAndFilter';
import AlertModal from '../components/AlertModal';
import ExportModal from '../components/ExportModal';

const Dashboard: React.FC = () => {
  const [searchTerm, setSearchTerm] = React.useState('');
  const [selectedFilter, setSelectedFilter] = React.useState('all');
  const [sortBy, setSortBy] = React.useState('newest');
  const [showAlertModal, setShowAlertModal] = React.useState(false);
  const [showExportModal, setShowExportModal] = React.useState(false);

  const stats = [
    {
      label: 'Competitors Tracked',
      value: '8',
      change: '+2',
      trend: 'up',
      icon: Eye
    },
    {
      label: 'Updates This Week',
      value: '23',
      change: '+12',
      trend: 'up',
      icon: TrendingUp
    },
    {
      label: 'Critical Alerts',
      value: '3',
      change: '-1',
      trend: 'down',
      icon: AlertCircle
    },
    {
      label: 'Avg Response Time',
      value: '2.4h',
      change: '-0.8h',
      trend: 'down',
      icon: Clock
    }
  ];

  const recentUpdates = [
    {
      id: 1,
      competitor: 'Slack',
      type: 'feature',
      title: 'Canvas Feature Launch',
      description: 'New collaborative workspace feature allowing visual project planning and team coordination.',
      timestamp: '2 hours ago',
      severity: 'high',
      tags: ['Product', 'Collaboration']
    },
    {
      id: 2,
      competitor: 'Notion',
      type: 'pricing',
      title: 'Enterprise Plan Update',
      description: 'Increased storage limits and added advanced security features to Enterprise tier.',
      timestamp: '5 hours ago',
      severity: 'medium',
      tags: ['Pricing', 'Enterprise']
    },
    {
      id: 3,
      competitor: 'Linear',
      type: 'ui',
      title: 'Mobile App Redesign',
      description: 'Complete overhaul of mobile interface with improved navigation and performance.',
      timestamp: '1 day ago',
      severity: 'medium',
      tags: ['UI/UX', 'Mobile']
    },
    {
      id: 4,
      competitor: 'Figma',
      type: 'feature',
      title: 'AI Design Assistant',
      description: 'Beta release of AI-powered design suggestions and automated layout optimization.',
      timestamp: '2 days ago',
      severity: 'high',
      tags: ['AI', 'Design']
    }
  ];

  const topCompetitors = [
    {
      name: 'Slack',
      logo: '💬',
      updateCount: 8,
      lastUpdate: '2 hours ago',
      trend: 'high'
    },
    {
      name: 'Notion',
      logo: '📝',
      updateCount: 5,
      lastUpdate: '5 hours ago',
      trend: 'medium'
    },
    {
      name: 'Linear',
      logo: '📊',
      updateCount: 4,
      lastUpdate: '1 day ago',
      trend: 'medium'
    },
    {
      name: 'Figma',
      logo: '🎨',
      updateCount: 6,
      lastUpdate: '2 days ago',
      trend: 'high'
    }
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard</h1>
        <p className="text-gray-600">Monitor your competitive landscape in real-time</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-all duration-200">
              <div className="flex items-center justify-between mb-4">
                <div className="p-2 bg-blue-50 rounded-lg">
                  <Icon className="w-6 h-6 text-blue-600" />
                </div>
                <div className={`flex items-center space-x-1 text-sm ${
                  stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {stat.trend === 'up' ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />}
                  <span className="font-medium">{stat.change}</span>
                </div>
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</div>
                <div className="text-sm text-gray-500">{stat.label}</div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Updates */}
        <div className="lg:col-span-2">
          <div className="mb-6">
            <SearchAndFilter
              searchTerm={searchTerm}
              onSearchChange={setSearchTerm}
              selectedFilter={selectedFilter}
              onFilterChange={setSelectedFilter}
              sortBy={sortBy}
              onSortChange={setSortBy}
            />
          </div>
          
          <div className="bg-white rounded-xl border border-gray-200">
            <div className="p-6 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900">Recent Updates</h2>
                <div className="flex space-x-2">
                  <button
                    onClick={() => setShowExportModal(true)}
                    className="flex items-center space-x-1 text-gray-600 hover:text-gray-700 font-medium text-sm"
                  >
                    <Download className="w-4 h-4" />
                    <span>Export</span>
                  </button>
                  <button className="text-blue-600 hover:text-blue-700 font-medium text-sm">
                    View All
                  </button>
                </div>
              </div>
            </div>
            <div className="divide-y divide-gray-100">
              {recentUpdates.map((update) => (
                <UpdateCard key={update.id} update={update} />
              ))}
            </div>
          </div>
        </div>

        {/* Top Competitors */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-200">
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-xl font-semibold text-gray-900">Top Competitors</h2>
            </div>
            <div className="p-6">
              <div className="space-y-4">
                {topCompetitors.map((competitor, index) => (
                  <CompetitorCard key={index} competitor={competitor} />
                ))}
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border border-blue-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <button className="w-full flex items-center space-x-3 p-3 bg-white rounded-lg hover:bg-gray-50 transition-colors">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Star className="w-4 h-4 text-blue-600" />
                </div>
                <span className="text-sm font-medium text-gray-700">Add Competitor</span>
              </button>
              <button
                onClick={() => setShowAlertModal(true)}
                className="w-full flex items-center space-x-3 p-3 bg-white rounded-lg hover:bg-gray-50 transition-colors"
              >
                <div className="p-2 bg-orange-100 rounded-lg">
                  <Bell className="w-4 h-4 text-orange-600" />
                </div>
                <span className="text-sm font-medium text-gray-700">Create Alert</span>
              </button>
              <button className="w-full flex items-center space-x-3 p-3 bg-white rounded-lg hover:bg-gray-50 transition-colors">
                <div className="p-2 bg-green-100 rounded-lg">
                  <Zap className="w-4 h-4 text-green-600" />
                </div>
                <span className="text-sm font-medium text-gray-700">Generate Report</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <AlertModal
        isOpen={showAlertModal}
        onClose={() => setShowAlertModal(false)}
      />

      <ExportModal
        isOpen={showExportModal}
        onClose={() => setShowExportModal(false)}
        type="report"
      />
    </div>
  );
};

export default Dashboard;