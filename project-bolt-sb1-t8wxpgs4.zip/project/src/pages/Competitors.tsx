import React, { useState } from 'react';
import { Plus, Search, Filter, MoreHorizontal, Globe, Twitter, Github, Bell, Trash2, Edit3 } from 'lucide-react';
import AlertModal from '../components/AlertModal';

const Competitors: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showAlertModal, setShowAlertModal] = useState(false);
  const [selectedCompetitor, setSelectedCompetitor] = useState('');
  const [showDropdown, setShowDropdown] = useState<number | null>(null);

  const competitors = [
    {
      id: 1,
      name: 'Slack',
      website: 'slack.com',
      description: 'Team collaboration and communication platform',
      logo: '💬',
      status: 'active',
      lastChecked: '5 mins ago',
      sources: ['Website', 'Blog', 'Twitter', 'App Store'],
      updateCount: 23,
      category: 'Communication'
    },
    {
      id: 2,
      name: 'Notion',
      website: 'notion.so',
      description: 'All-in-one workspace for notes, tasks, and collaboration',
      logo: '📝',
      status: 'active',
      lastChecked: '12 mins ago',
      sources: ['Website', 'Changelog', 'Twitter'],
      updateCount: 18,
      category: 'Productivity'
    },
    {
      id: 3,
      name: 'Linear',
      website: 'linear.app',
      description: 'Issue tracking and project management for software teams',
      logo: '📊',
      status: 'active',
      lastChecked: '8 mins ago',
      sources: ['Website', 'Blog', 'GitHub'],
      updateCount: 15,
      category: 'Project Management'
    },
    {
      id: 4,
      name: 'Figma',
      website: 'figma.com',
      description: 'Collaborative design and prototyping platform',
      logo: '🎨',
      status: 'active',
      lastChecked: '3 mins ago',
      sources: ['Website', 'Blog', 'Twitter', 'YouTube'],
      updateCount: 31,
      category: 'Design'
    },
    {
      id: 5,
      name: 'Miro',
      website: 'miro.com',
      description: 'Online collaborative whiteboard platform',
      logo: '🗂️',
      status: 'paused',
      lastChecked: '2 hours ago',
      sources: ['Website', 'Blog'],
      updateCount: 9,
      category: 'Collaboration'
    }
  ];

  const filteredCompetitors = competitors.filter(competitor =>
    competitor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    competitor.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Competitors</h1>
          <p className="text-gray-600">Manage your competitive watchlist</p>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span>Add Competitor</span>
        </button>
      </div>

      {/* Search and Filter Bar */}
      <div className="flex items-center space-x-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search competitors..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
          <Filter className="w-5 h-5" />
          <span>Filter</span>
        </button>
      </div>

      {/* Competitors Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCompetitors.map((competitor) => (
          <div key={competitor.id} className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-all duration-200">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="text-3xl">{competitor.logo}</div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{competitor.name}</h3>
                  <p className="text-sm text-gray-500">{competitor.website}</p>
                </div>
              </div>
              <div className="relative">
                <button
                  onClick={() => setShowDropdown(showDropdown === competitor.id ? null : competitor.id)}
                  className="p-2 hover:bg-gray-100 rounded-lg"
                >
                  <MoreHorizontal className="w-5 h-5 text-gray-400" />
                </button>
                
                {showDropdown === competitor.id && (
                  <div className="absolute right-0 top-10 bg-white border border-gray-200 rounded-lg shadow-lg z-10 w-48">
                    <button
                      onClick={() => {
                        setSelectedCompetitor(competitor.name);
                        setShowAlertModal(true);
                        setShowDropdown(null);
                      }}
                      className="w-full flex items-center space-x-2 px-4 py-2 text-left hover:bg-gray-50"
                    >
                      <Bell className="w-4 h-4 text-gray-400" />
                      <span className="text-sm">Create Alert</span>
                    </button>
                    <button className="w-full flex items-center space-x-2 px-4 py-2 text-left hover:bg-gray-50">
                      <Edit3 className="w-4 h-4 text-gray-400" />
                      <span className="text-sm">Edit Details</span>
                    </button>
                    <button className="w-full flex items-center space-x-2 px-4 py-2 text-left hover:bg-gray-50 text-red-600">
                      <Trash2 className="w-4 h-4" />
                      <span className="text-sm">Remove</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            <p className="text-gray-600 mb-4">{competitor.description}</p>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Status</span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  competitor.status === 'active' 
                    ? 'bg-green-100 text-green-700' 
                    : 'bg-yellow-100 text-yellow-700'
                }`}>
                  {competitor.status}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Updates</span>
                <span className="text-sm font-semibold text-gray-900">{competitor.updateCount}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Last Checked</span>
                <span className="text-sm text-gray-900">{competitor.lastChecked}</span>
              </div>

              <div>
                <span className="text-sm text-gray-500 block mb-2">Sources</span>
                <div className="flex flex-wrap gap-2">
                  {competitor.sources.map((source, index) => (
                    <span key={index} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-md">
                      {source}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-gray-100">
                <div className="flex items-center justify-between">
                  <div className="flex space-x-2">
                    <button className="p-2 hover:bg-gray-100 rounded-lg">
                      <Globe className="w-4 h-4 text-gray-400" />
                    </button>
                    <button className="p-2 hover:bg-gray-100 rounded-lg">
                      <Twitter className="w-4 h-4 text-gray-400" />
                    </button>
                    <button className="p-2 hover:bg-gray-100 rounded-lg">
                      <Github className="w-4 h-4 text-gray-400" />
                    </button>
                  </div>
                  <span className={`px-2 py-1 rounded-md text-xs ${
                    competitor.category === 'Communication' ? 'bg-blue-100 text-blue-700' :
                    competitor.category === 'Productivity' ? 'bg-purple-100 text-purple-700' :
                    competitor.category === 'Project Management' ? 'bg-green-100 text-green-700' :
                    competitor.category === 'Design' ? 'bg-pink-100 text-pink-700' :
                    'bg-orange-100 text-orange-700'
                  }`}>
                    {competitor.category}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Competitor Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Add New Competitor</h2>
            <form className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Company Name</label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., Slack"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Website URL</label>
                <input
                  type="url"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="https://example.com"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                <textarea
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  rows={3}
                  placeholder="Brief description of the competitor"
                />
              </div>
              <div className="flex space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Add Competitor
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <AlertModal
        isOpen={showAlertModal}
        onClose={() => setShowAlertModal(false)}
        competitor={selectedCompetitor}
      />
    </div>
  );
};

export default Competitors;