import React, { useState } from 'react';
import { Calendar, Filter, Download, ChevronDown, Bell } from 'lucide-react';
import ExportModal from '../components/ExportModal';
import AlertModal from '../components/AlertModal';

const Timeline: React.FC = () => {
  const [selectedCompetitor, setSelectedCompetitor] = useState('all');
  const [selectedTimeframe, setSelectedTimeframe] = useState('30d');
  const [showExportModal, setShowExportModal] = useState(false);
  const [showAlertModal, setShowAlertModal] = useState(false);
  const [selectedCompetitorForAlert, setSelectedCompetitorForAlert] = useState('');

  const timelineEvents = [
    {
      id: 1,
      date: '2024-01-15',
      time: '14:30',
      competitor: 'Slack',
      type: 'feature',
      title: 'Canvas Feature Launch',
      description: 'Slack announced a new Canvas feature for visual collaboration, directly competing with Miro and Figma.',
      impact: 'high',
      logo: '💬'
    },
    {
      id: 2,
      date: '2024-01-14',
      time: '09:15',
      competitor: 'Notion',
      type: 'pricing',
      title: 'Enterprise Plan Updates',
      description: 'Notion updated their Enterprise pricing with enhanced security features and increased storage.',
      impact: 'medium',
      logo: '📝'
    },
    {
      id: 3,
      date: '2024-01-12',
      time: '16:45',
      competitor: 'Linear',
      type: 'ui',
      title: 'Mobile App Redesign',
      description: 'Linear launched a completely redesigned mobile experience with improved performance.',
      impact: 'medium',
      logo: '📊'
    },
    {
      id: 4,
      date: '2024-01-10',
      time: '11:20',
      competitor: 'Figma',
      type: 'feature',
      title: 'AI Design Assistant Beta',
      description: 'Figma released beta access to their AI-powered design assistant for Pro users.',
      impact: 'high',
      logo: '🎨'
    },
    {
      id: 5,
      date: '2024-01-08',
      time: '13:55',
      competitor: 'Slack',
      type: 'integration',
      title: 'Salesforce Integration Enhancement',
      description: 'Enhanced Salesforce integration with real-time data sync and improved workflow automation.',
      impact: 'medium',
      logo: '💬'
    },
    {
      id: 6,
      date: '2024-01-05',
      time: '10:30',
      competitor: 'Notion',
      type: 'feature',
      title: 'Database Templates Library',
      description: 'Launched a comprehensive library of pre-built database templates for common use cases.',
      impact: 'medium',
      logo: '📝'
    }
  ];

  const competitors = ['all', 'Slack', 'Notion', 'Linear', 'Figma'];
  const timeframes = [
    { value: '7d', label: 'Last 7 days' },
    { value: '30d', label: 'Last 30 days' },
    { value: '90d', label: 'Last 3 months' },
    { value: '1y', label: 'Last year' }
  ];

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'feature':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'pricing':
        return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'ui':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'integration':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'low':
        return 'bg-green-100 text-green-700 border-green-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  const filteredEvents = timelineEvents.filter(event => 
    selectedCompetitor === 'all' || event.competitor === selectedCompetitor
  );

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Competitive Timeline</h1>
          <p className="text-gray-600">Track competitor activities over time</p>
        </div>
        <button 
          onClick={() => setShowExportModal(true)}
          className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Download className="w-5 h-5" />
          <span>Export Timeline</span>
        </button>
      </div>

      {/* Filters */}
      <div className="flex items-center space-x-4 bg-white p-4 rounded-xl border border-gray-200">
        <div className="flex items-center space-x-2">
          <Filter className="w-5 h-5 text-gray-400" />
          <span className="text-sm font-medium text-gray-700">Filter by:</span>
        </div>
        
        <div className="relative">
          <select
            value={selectedCompetitor}
            onChange={(e) => setSelectedCompetitor(e.target.value)}
            className="appearance-none bg-white border border-gray-300 rounded-lg px-3 py-2 pr-8 text-sm focus:ring-2 focus:ring-blue-500"
          >
            {competitors.map(competitor => (
              <option key={competitor} value={competitor}>
                {competitor === 'all' ? 'All Competitors' : competitor}
              </option>
            ))}
          </select>
          <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
        </div>

        <div className="relative">
          <select
            value={selectedTimeframe}
            onChange={(e) => setSelectedTimeframe(e.target.value)}
            className="appearance-none bg-white border border-gray-300 rounded-lg px-3 py-2 pr-8 text-sm focus:ring-2 focus:ring-blue-500"
          >
            {timeframes.map(timeframe => (
              <option key={timeframe.value} value={timeframe.value}>
                {timeframe.label}
              </option>
            ))}
          </select>
          <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
        </div>
      </div>

      {/* Timeline */}
      <div className="bg-white rounded-xl border border-gray-200">
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gray-200"></div>
          
          <div className="space-y-0">
            {filteredEvents.map((event, index) => (
              <div key={event.id} className="relative flex items-start p-6 hover:bg-gray-50 transition-colors">
                {/* Timeline dot */}
                <div className="absolute left-6 w-4 h-4 bg-white border-4 border-blue-500 rounded-full"></div>
                
                {/* Content */}
                <div className="ml-16 flex-1">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="text-2xl">{event.logo}</div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">{event.title}</h3>
                        <div className="flex items-center space-x-2 text-sm text-gray-500">
                          <Calendar className="w-4 h-4" />
                          <span>{formatDate(event.date)} at {event.time}</span>
                          <span>•</span>
                          <span className="font-medium">{event.competitor}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 rounded-full border text-xs font-medium ${getTypeColor(event.type)}`}>
                        {event.type}
                      </span>
                      <span className={`px-2 py-1 rounded-full border text-xs font-medium ${getImpactColor(event.impact)}`}>
                        {event.impact} impact
                      </span>
                    </div>
                  </div>
                  
                  <p className="text-gray-600 leading-relaxed">{event.description}</p>
                  
                  <div className="mt-4 pt-3 border-t border-gray-100">
                    <button
                      onClick={() => {
                        setSelectedCompetitorForAlert(event.competitor);
                        setShowAlertModal(true);
                      }}
                      className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 text-sm font-medium"
                    >
                      <Bell className="w-4 h-4" />
                      <span>Create Alert for {event.competitor}</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <ExportModal
        isOpen={showExportModal}
        onClose={() => setShowExportModal(false)}
        type="timeline"
      />

      <AlertModal
        isOpen={showAlertModal}
        onClose={() => setShowAlertModal(false)}
        competitor={selectedCompetitorForAlert}
      />
    </div>
  );
};

export default Timeline;