import React, { useState } from 'react';
import { Download, TrendingUp, BarChart3, PieChart, Calendar, Share2 } from 'lucide-react';
import ExportModal from '../components/ExportModal';

const Reports: React.FC = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const [showExportModal, setShowExportModal] = useState(false);

  const reportStats = [
    {
      title: 'Total Updates Tracked',
      value: '156',
      change: '+23%',
      trend: 'up',
      icon: TrendingUp
    },
    {
      title: 'High Impact Changes',
      value: '12',
      change: '+4',
      trend: 'up',
      icon: BarChart3
    },
    {
      title: 'Active Competitors',
      value: '8',
      change: '0',
      trend: 'stable',
      icon: PieChart
    },
    {
      title: 'Avg Response Time',
      value: '2.4h',
      change: '-0.8h',
      trend: 'down',
      icon: Calendar
    }
  ];

  const weeklyReport = {
    period: 'January 8-14, 2024',
    summary: 'This week saw significant activity from Slack and Figma, with major feature launches that could impact our competitive position.',
    highlights: [
      {
        competitor: 'Slack',
        change: 'Canvas Feature Launch',
        impact: 'High',
        description: 'New visual collaboration feature directly competing with our whiteboard functionality.',
        recommendation: 'Consider accelerating our visual collaboration roadmap features.'
      },
      {
        competitor: 'Figma',
        change: 'AI Design Assistant Beta',
        impact: 'High',
        description: 'AI-powered design suggestions and automated layout optimization.',
        recommendation: 'Evaluate AI integration opportunities for our design tools.'
      },
      {
        competitor: 'Notion',
        change: 'Enterprise Security Updates',
        impact: 'Medium',
        description: 'Enhanced security features and compliance certifications.',
        recommendation: 'Review our enterprise security positioning.'
      }
    ],
    trends: [
      'AI integration is becoming a key differentiator across all platforms',
      'Visual collaboration features are being prioritized by communication tools',
      'Enterprise security and compliance are table stakes for B2B growth'
    ],
    nextWeekFocus: [
      'Monitor Slack Canvas adoption and user feedback',
      'Research AI design tool market trends',
      'Audit our current enterprise security features'
    ]
  };

  const competitorBreakdown = [
    { name: 'Slack', updates: 8, percentage: 35 },
    { name: 'Notion', updates: 5, percentage: 22 },
    { name: 'Figma', updates: 6, percentage: 26 },
    { name: 'Linear', updates: 4, percentage: 17 }
  ];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Reports</h1>
          <p className="text-gray-600">AI-generated competitive intelligence summaries</p>
        </div>
        <div className="flex space-x-3">
          <select
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value)}
            className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500"
          >
            <option value="week">This Week</option>
            <option value="month">This Month</option>
            <option value="quarter">This Quarter</option>
          </select>
          <button 
            onClick={() => setShowExportModal(true)}
            className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Download className="w-5 h-5" />
            <span>Export Report</span>
          </button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {reportStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <div className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                    AI Generated
                  </div>
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                    <Share2 className="w-4 h-4 text-gray-400" />
                  </button>
                </div>
                <span className={`text-sm font-medium ${
                  stat.trend === 'up' ? 'text-green-600' : 
                  stat.trend === 'down' ? 'text-red-600' : 'text-gray-600'
                }`}>
                  {stat.change}
                </span>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</div>
              <div className="text-sm text-gray-500">{stat.title}</div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Weekly Report */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200">
          <div className="p-6 border-b border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold text-gray-900">Weekly Intelligence Report</h2>
                <p className="text-sm text-gray-500 mt-1">{weeklyReport.period}</p>
              </div>
              <div className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                AI Generated
              </div>
            </div>
          </div>
          
          <div className="p-6 space-y-6">
            {/* Executive Summary */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Executive Summary</h3>
              <p className="text-gray-600 leading-relaxed">{weeklyReport.summary}</p>
            </div>

            {/* Key Highlights */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Key Highlights</h3>
              <div className="space-y-4">
                {weeklyReport.highlights.map((highlight, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <span className="font-semibold text-gray-900">{highlight.competitor}</span>
                        <span className="text-gray-500">•</span>
                        <span className="text-gray-700">{highlight.change}</span>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        highlight.impact === 'High' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                      }`}>
                        {highlight.impact} Impact
                      </span>
                    </div>
                    <p className="text-gray-600 text-sm mb-2">{highlight.description}</p>
                    <p className="text-blue-700 text-sm font-medium">💡 {highlight.recommendation}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Trends */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Market Trends</h3>
              <ul className="space-y-2">
                {weeklyReport.trends.map((trend, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                    <span className="text-gray-600">{trend}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Next Week Focus */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Next Week Focus</h3>
              <ul className="space-y-2">
                {weeklyReport.nextWeekFocus.map((item, index) => (
                  <li key={index} className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-600 rounded-full flex-shrink-0"></div>
                    <span className="text-gray-600">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Competitor Activity Breakdown */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-200">
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-xl font-semibold text-gray-900">Activity Breakdown</h2>
            </div>
            <div className="p-6">
              <div className="space-y-4">
                {competitorBreakdown.map((competitor, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-medium text-gray-900">{competitor.name}</span>
                      <span className="text-gray-600">{competitor.updates} updates</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${competitor.percentage}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border border-blue-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Quick Actions</h3>
            <div className="space-y-3">
              <button className="w-full text-left p-3 bg-white rounded-lg hover:bg-gray-50 transition-colors">
                <div className="font-medium text-gray-900">Schedule Team Briefing</div>
                <div className="text-sm text-gray-600">Share insights with product team</div>
              </button>
              <button className="w-full text-left p-3 bg-white rounded-lg hover:bg-gray-50 transition-colors">
                <div className="font-medium text-gray-900">Create Action Items</div>
                <div className="text-sm text-gray-600">Convert insights to tasks</div>
              </button>
            </div>
          </div>
        </div>
      </div>

      <ExportModal
        isOpen={showExportModal}
        onClose={() => setShowExportModal(false)}
        type="report"
      />
    </div>
  );
};

export default Reports;