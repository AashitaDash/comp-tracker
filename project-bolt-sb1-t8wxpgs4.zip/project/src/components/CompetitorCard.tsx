import React from 'react';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface CompetitorCardProps {
  competitor: {
    name: string;
    logo: string;
    updateCount: number;
    lastUpdate: string;
    trend: string;
  };
}

const CompetitorCard: React.FC<CompetitorCardProps> = ({ competitor }) => {
  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'high':
        return <TrendingUp className="w-4 h-4 text-green-600" />;
      case 'low':
        return <TrendingDown className="w-4 h-4 text-red-600" />;
      default:
        return <Minus className="w-4 h-4 text-gray-600" />;
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'high':
        return 'bg-green-50 border-green-200';
      case 'low':
        return 'bg-red-50 border-red-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:shadow-md transition-all duration-200">
      <div className="flex items-center space-x-3">
        <div className="text-2xl">{competitor.logo}</div>
        <div>
          <div className="font-semibold text-gray-900">{competitor.name}</div>
          <div className="text-sm text-gray-500">{competitor.lastUpdate}</div>
        </div>
      </div>
      <div className="flex items-center space-x-3">
        <div className="text-right">
          <div className="text-lg font-bold text-gray-900">{competitor.updateCount}</div>
          <div className="text-xs text-gray-500">updates</div>
        </div>
        <div className={`p-2 rounded-lg border ${getTrendColor(competitor.trend)}`}>
          {getTrendIcon(competitor.trend)}
        </div>
      </div>
    </div>
  );
};

export default CompetitorCard;