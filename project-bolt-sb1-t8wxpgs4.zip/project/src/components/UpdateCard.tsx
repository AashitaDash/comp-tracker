import React from 'react';
import { Clock, Tag, AlertTriangle, TrendingUp, DollarSign, Monitor, ExternalLink, Bookmark } from 'lucide-react';

interface UpdateCardProps {
  update: {
    id: number;
    competitor: string;
    type: string;
    title: string;
    description: string;
    timestamp: string;
    severity: string;
    tags: string[];
  };
}

const UpdateCard: React.FC<UpdateCardProps> = ({ update }) => {
  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'feature':
        return <TrendingUp className="w-4 h-4" />;
      case 'pricing':
        return <DollarSign className="w-4 h-4" />;
      case 'ui':
        return <Monitor className="w-4 h-4" />;
      default:
        return <Tag className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'feature':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'pricing':
        return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'ui':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'text-red-600';
      case 'medium':
        return 'text-yellow-600';
      case 'low':
        return 'text-green-600';
      default:
        return 'text-gray-600';
    }
  };

  return (
    <div className="p-6 hover:bg-gray-50 transition-colors">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-3">
          <div className={`flex items-center space-x-2 px-3 py-1 rounded-full border text-sm font-medium ${getTypeColor(update.type)}`}>
            {getTypeIcon(update.type)}
            <span className="capitalize">{update.type}</span>
          </div>
          <span className="text-lg font-semibold text-gray-900">{update.competitor}</span>
        </div>
        <div className="flex items-center space-x-2">
          <AlertTriangle className={`w-4 h-4 ${getSeverityColor(update.severity)}`} />
          <span className={`text-xs font-medium uppercase tracking-wide ${getSeverityColor(update.severity)}`}>
            {update.severity}
          </span>
        </div>
      </div>
      
      <div className="mb-3">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">{update.title}</h3>
        <p className="text-gray-600 leading-relaxed">{update.description}</p>
      </div>
      
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          {update.tags.map((tag, index) => (
            <span key={index} className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-md">
              {tag}
            </span>
          ))}
        </div>
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1 text-gray-500">
            <Clock className="w-4 h-4" />
            <span className="text-sm">{update.timestamp}</span>
          </div>
          <div className="flex items-center space-x-1">
            <button className="p-1 hover:bg-gray-100 rounded transition-colors">
              <Bookmark className="w-4 h-4 text-gray-400" />
            </button>
            <button className="p-1 hover:bg-gray-100 rounded transition-colors">
              <ExternalLink className="w-4 h-4 text-gray-400" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UpdateCard;